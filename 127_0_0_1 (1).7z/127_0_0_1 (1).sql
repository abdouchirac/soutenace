-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 31 août 2022 à 13:40
-- Version du serveur : 5.7.36
-- Version de PHP : 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `j_sendmail`
--
CREATE DATABASE IF NOT EXISTS `j_sendmail` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `j_sendmail`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `emplacement_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `courriers`
--

INSERT INTO `courriers` (`id`, `courrier_libele`, `courrier_date_arrive`, `courrier_status`, `emeteur_id`, `user_id`, `emplacement_id`, `created_at`, `updated_at`) VALUES
(3, 'bouitelle', '2022-08-26', 'enStok', 1, 1, 1, '2022-08-24 14:32:33', '2022-08-25 14:01:42');

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int(11) NOT NULL,
  `destinataire_pasword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `emeteurs`
--

INSERT INTO `emeteurs` (`id`, `emeteur_noms`, `created_at`, `updated_at`) VALUES
(1, 'hehehe', '2022-08-24 14:28:33', '2022-08-24 14:28:33');

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `emplacements`
--

INSERT INTO `emplacements` (`id`, `emplacement_noms`, `emplacement_detail`, `created_at`, `updated_at`) VALUES
(1, 'zzksksg', 'cctt', '2022-08-24 14:26:22', '2022-08-24 14:26:22');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `historiques`
--

INSERT INTO `historiques` (`id`, `poste_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2022-08-18 13:22:38', '2022-08-18 13:22:38'),
(2, 2, 2, '2022-08-18 15:06:22', '2022-08-18 15:06:22'),
(3, 3, 3, '2022-08-29 13:49:22', '2022-08-29 13:49:22');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `images` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(19, '2014_10_12_000000_create_users_table', 4),
(20, '2014_10_12_100000_create_password_resets_table', 4),
(21, '2019_08_19_000000_create_failed_jobs_table', 4),
(22, '2022_06_16_105357_create_receptionistes_table', 4),
(23, '2022_06_16_114634_create_emplacements_table', 4),
(24, '2022_06_16_115737_create_destinataires_table', 4),
(25, '2022_06_16_121946_create_postes_table', 4),
(26, '2022_06_16_130707_create_historiques_table', 4),
(27, '2022_06_16_132853_create_emeteurs_table', 4),
(28, '2022_06_16_133129_create_courriers_table', 4),
(13, '2022_08_12_120856_userrole_table', 1),
(14, '2022_08_16_103713_user_permissions_table', 2),
(15, '2022_08_16_103910_permissions_table', 2),
(17, '2022_08_16_102418_permission_table', 3),
(18, '2022_08_16_102503_userpermission_table', 3),
(29, '2022_06_20_105740_create_roles_table', 4),
(30, '2022_06_24_082540_create_messages_table', 4),
(31, '2022_07_05_133006_create_notifications_table', 4),
(32, '2022_07_17_153444_create_images_table', 4);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('27ea753f-a4d6-4a9a-b57d-c1157f738b8e', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"savon\",\"courrier_date_arrive\":\"2022-08-18\",\"emeteur_id\":\"1\",\"user_id\":\"2\",\"emplacement_id\":\"1\"}}', NULL, '2022-08-24 14:30:26', '2022-08-24 14:30:26'),
('65dfc364-0393-444d-90c3-0d52621471f6', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 2, '{\"state\":{\"courrier_libele\":\"savon\",\"courrier_date_arrive\":\"2022-08-18\",\"emeteur_id\":\"1\",\"user_id\":\"2\",\"emplacement_id\":\"1\"}}', NULL, '2022-08-24 14:30:26', '2022-08-24 14:30:26'),
('78e9e225-e36a-4c4e-ae1b-229be1d7161c', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 1, '{\"state\":{\"courrier_libele\":\"bouitell\",\"courrier_date_arrive\":\"2022-08-26\",\"emeteur_id\":\"1\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-08-24 14:32:37', '2022-08-24 14:32:37'),
('2ab19e6f-0f8c-4410-a53f-413236d03e8a', 'App\\Notifications\\courriernotification', 'App\\Models\\User', 2, '{\"state\":{\"courrier_libele\":\"bouitell\",\"courrier_date_arrive\":\"2022-08-26\",\"emeteur_id\":\"1\",\"user_id\":\"1\",\"emplacement_id\":\"1\"}}', NULL, '2022-08-24 14:32:37', '2022-08-24 14:32:37');

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_libele`) VALUES
(1, 'ajouter les courriers'),
(2, 'modifier les courriers'),
(3, 'supprimer les courriers'),
(4, 'déstocker les courriers'),
(5, 'ajouter les emplacements'),
(6, 'modifier les emplacements'),
(7, 'ajouter les émetteurs'),
(8, 'modifier les émetteurs'),
(9, 'valider la réception des courriers'),
(10, 'voir les courriers'),
(11, 'consulter la liste des courriers'),
(12, 'consulter la liste des emplacements'),
(13, 'consulter la liste des émetteurs'),
(14, 'ajouter les utilisateurs'),
(15, 'afficher les utilisateurs'),
(16, 'consulter la liste des utilisateurs'),
(17, 'modifier le profil des utilisateurs'),
(18, 'voir les emplacements');

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postes_id_unique` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'dircteur', '2022-08-18 13:22:38', '2022-08-18 13:22:38'),
(2, 'dircteur', '2022-08-18 15:06:22', '2022-08-18 15:06:22'),
(3, 'developpeur', '2022-08-29 13:49:22', '2022-08-29 13:49:22');

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('vvotYftfPhP6Ymxp4PP1A08Ib3qxT4qM5mi4mk8S', 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQXkwb2dkQ1pSN2FtWjJpempROUdtNjZXZHdER0NsMUJwSHRBV2dGYyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9jb3Vycmllci1pbmRleCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==', 1661872360);

-- --------------------------------------------------------

--
-- Structure de la table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE IF NOT EXISTS `userrole` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  KEY `userrole_user_id_foreign` (`user_id`),
  KEY `userrole_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `userrole`
--

INSERT INTO `userrole` (`user_id`, `role_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint(20) UNSIGNED DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint(4) NOT NULL DEFAULT '1',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'status',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_image_id_foreign` (`image_id`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `image_id`, `password`, `user_type`, `age`, `address`, `utype`, `number`, `city`, `ZIP`, `email_verified_at`, `role_id`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'dubel ', 'nguemle', NULL, 'dubelnguemle@gmail.com', NULL, '$2y$10$HgNcxxz21axZZ6IwWSGABup5xl4FmPHb6V1ypyZoQzqq2TAQuFWXi', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-18 13:22:38', '2022-08-18 13:22:38'),
(2, 'bab', 'nguemle', NULL, 'L@gmail.com', NULL, '$2y$10$SZgTou4gXn4G8WmUmX2lKuk3A4c/kmbiJ4ORHa12uVU/RPIwWHBmu', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-18 15:06:22', '2022-08-18 15:06:22'),
(3, 'cain', 'abel', NULL, 'abel@gmail.com', NULL, '$2y$10$nE8PDCbWGKHGpdUwxn2gfeJniJBT.7CabzUoQsD.ywSz3gVyPNdly', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-29 13:49:22', '2022-08-29 13:49:22');

-- --------------------------------------------------------

--
-- Structure de la table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE IF NOT EXISTS `user_permissions` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `user_permissions_user_id_foreign` (`user_id`),
  KEY `user_permissions_permission_id_foreign` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `user_permissions`
--

INSERT INTO `user_permissions` (`user_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(2, 15, '2022-08-29 13:37:27', '2022-08-29 13:37:27'),
(2, 16, '2022-08-29 13:37:27', '2022-08-29 13:37:27'),
(2, 2, '2022-08-29 13:38:10', '2022-08-29 13:38:10'),
(2, 16, '2022-08-29 13:38:10', '2022-08-29 13:38:10'),
(2, 2, '2022-08-29 13:38:12', '2022-08-29 13:38:12'),
(2, 16, '2022-08-29 13:38:12', '2022-08-29 13:38:12'),
(2, 16, '2022-08-29 13:42:11', '2022-08-29 13:42:11'),
(2, 14, '2022-08-29 13:42:11', '2022-08-29 13:42:11'),
(2, 13, '2022-08-29 13:42:11', '2022-08-29 13:42:11'),
(2, 12, '2022-08-29 13:42:11', '2022-08-29 13:42:11'),
(2, 10, '2022-08-29 13:42:59', '2022-08-29 13:42:59'),
(2, 8, '2022-08-29 13:42:59', '2022-08-29 13:42:59'),
(2, 7, '2022-08-29 13:42:59', '2022-08-29 13:42:59'),
(2, 8, '2022-08-29 13:43:39', '2022-08-29 13:43:39'),
(2, 9, '2022-08-29 13:43:39', '2022-08-29 13:43:39'),
(2, 10, '2022-08-29 13:43:39', '2022-08-29 13:43:39'),
(2, 11, '2022-08-29 13:45:26', '2022-08-29 13:45:26'),
(2, 12, '2022-08-29 13:45:26', '2022-08-29 13:45:26'),
(1, 11, '2022-08-30 06:59:55', '2022-08-30 06:59:55'),
(3, 11, '2022-08-30 14:12:36', '2022-08-30 14:12:36'),
(3, 13, '2022-08-30 14:11:54', '2022-08-30 14:11:54'),
(1, 12, '2022-08-30 07:03:53', '2022-08-30 07:03:53'),
(1, 10, '2022-08-30 07:06:10', '2022-08-30 07:06:10'),
(1, 12, '2022-08-30 07:07:57', '2022-08-30 07:07:57'),
(1, 1, '2022-08-30 07:20:07', '2022-08-30 07:20:07');
--
-- Base de données : `j_sentmail`
--
CREATE DATABASE IF NOT EXISTS `j_sentmail` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `j_sentmail`;

-- --------------------------------------------------------

--
-- Structure de la table `courriers`
--

DROP TABLE IF EXISTS `courriers`;
CREATE TABLE IF NOT EXISTS `courriers` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `courrier_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courrier_date_arrive` date NOT NULL,
  `courrier_status` enum('enStok','enCours','destoke') COLLATE utf8mb4_unicode_ci NOT NULL,
  `emeteur_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `emplacement_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courriers_emeteur_id_foreign` (`emeteur_id`),
  KEY `courriers_user_id_foreign` (`user_id`),
  KEY `courriers_emplacement_id_foreign` (`emplacement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `destinataires`
--

DROP TABLE IF EXISTS `destinataires`;
CREATE TABLE IF NOT EXISTS `destinataires` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `destinataire_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinataire_telephone` int(11) NOT NULL,
  `destinataire_pasword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emeteurs`
--

DROP TABLE IF EXISTS `emeteurs`;
CREATE TABLE IF NOT EXISTS `emeteurs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `emeteur_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `emplacements`
--

DROP TABLE IF EXISTS `emplacements`;
CREATE TABLE IF NOT EXISTS `emplacements` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `emplacement_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emplacement_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_poste_id_foreign` (`poste_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `historiques`
--

INSERT INTO `historiques` (`id`, `poste_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2022-08-18 14:22:03', '2022-08-18 14:22:03');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `images` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_06_16_105357_create_receptionistes_table', 1),
(5, '2022_06_16_114634_create_emplacements_table', 1),
(6, '2022_06_16_115737_create_destinataires_table', 1),
(7, '2022_06_16_121946_create_postes_table', 1),
(8, '2022_06_16_130707_create_historiques_table', 1),
(9, '2022_06_16_132853_create_emeteurs_table', 1),
(10, '2022_06_16_133129_create_courriers_table', 1),
(11, '2022_06_20_105740_create_roles_table', 1),
(12, '2022_06_24_082540_create_messages_table', 1),
(13, '2022_07_05_133006_create_notifications_table', 1),
(14, '2022_07_17_153444_create_images_table', 1),
(15, '2022_08_12_120856_userrole_table', 2),
(16, '2022_08_16_102418_permission_table', 2),
(17, '2022_08_16_102503_userpermission_table', 2),
(18, '2022_08_16_103713_user_permissions_table', 2),
(19, '2022_08_16_103910_permissions_table', 2);

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_libele`) VALUES
(1, 'ajouter les courriers'),
(2, 'modifier les courriers'),
(3, 'supprimer les courriers'),
(4, 'déstocker les courriers'),
(5, 'ajouter les emplacements'),
(6, 'modifier les emplacements'),
(7, 'ajouter les émetteurs'),
(8, 'modifier les émetteurs'),
(9, 'valider la réception des courriers'),
(10, 'voir les courriers'),
(11, 'consulter la liste des courriers'),
(12, 'consulter la liste des emplacements'),
(13, 'consulter la liste des émetteurs'),
(14, 'ajouter les utilisateurs'),
(15, 'afficher les utilisateurs'),
(16, 'consulter la liste des utilisateurs'),
(17, 'modifier le profil des utilisateurs');

-- --------------------------------------------------------

--
-- Structure de la table `postes`
--

DROP TABLE IF EXISTS `postes`;
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `poste_libele` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postes_id_unique` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `postes`
--

INSERT INTO `postes` (`id`, `poste_libele`, `created_at`, `updated_at`) VALUES
(1, 'dircteur', '2022-08-18 14:22:03', '2022-08-18 14:22:03');

-- --------------------------------------------------------

--
-- Structure de la table `receptionistes`
--

DROP TABLE IF EXISTS `receptionistes`;
CREATE TABLE IF NOT EXISTS `receptionistes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `receptioniste_noms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_prenoms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receptioniste_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `first_name`, `last_name`) VALUES
(1, 'admin', '');

-- --------------------------------------------------------

--
-- Structure de la table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('5Ins61E4y7QGAWtzRDs1D3OfzOkqXDIDfzYRRmij', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMHh0MVQ0QzdtaTh4VW9GbVo5Nzg4TlB2dEtGalZRN0o5dWIzMnlhYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9jb3Vycmllci1pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1660838309);

-- --------------------------------------------------------

--
-- Structure de la table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE IF NOT EXISTS `userrole` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  KEY `userrole_user_id_foreign` (`user_id`),
  KEY `userrole_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `userrole`
--

INSERT INTO `userrole` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` bigint(20) UNSIGNED DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `age` tinyint(4) NOT NULL DEFAULT '1',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'ADM for Admin and USR for user or Customer',
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ZIP` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT 'status',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_remember_token_unique` (`remember_token`),
  KEY `users_image_id_foreign` (`image_id`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `image_id`, `password`, `user_type`, `age`, `address`, `utype`, `number`, `city`, `ZIP`, `email_verified_at`, `role_id`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'dubel ', 'nguemle', NULL, 'dubelnguemle@gmail.com', NULL, '$2y$10$BuIGKalAOjfUfFrKHju6M.V6P8PaxdTaLUJFykgVvojILQM2yA6WO', 'user', 1, NULL, '1', NULL, NULL, NULL, NULL, 1, '1', NULL, '2022-08-18 14:22:03', '2022-08-18 14:22:03');

-- --------------------------------------------------------

--
-- Structure de la table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE IF NOT EXISTS `user_permissions` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  KEY `user_permissions_user_id_foreign` (`user_id`),
  KEY `user_permissions_user_permission_id_foreign` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Base de données : `line`
--
CREATE DATABASE IF NOT EXISTS `line` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `line`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
